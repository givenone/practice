./a {filename} {time}


ex : 
./a test 1
-> test.csv with time interval 1